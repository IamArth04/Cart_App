import 'package:flutter/material.dart';

class PriceItem extends StatelessWidget {
  const PriceItem({super.key, required this.value, required this.subTitle});

  final String value;
  final String subTitle;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Text(
          subTitle,
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w500,
          ),
        ),
        const Spacer(),
        Text(
          "\$$value", //"\$" + value
          style: TextStyle(
            fontSize: 16,
            color: Colors.grey.shade600,
          ),
        ),
      ],
    );
  }
}
